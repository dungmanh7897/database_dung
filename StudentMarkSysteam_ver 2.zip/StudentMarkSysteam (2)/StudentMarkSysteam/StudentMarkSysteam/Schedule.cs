﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentMarkSysteam
{
    public partial class Schedule : Form
    {
        string connectionString;
        SqlConnection con;
        public Schedule()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Student_grading; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void dgvSchedule_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Schedule_Load(object sender, EventArgs e)
        {
            FillGrid();
        }
        public void FillGrid()
        {
            string query = "SELECT Teachers_Course.T_ID, Teachers.T_Name, Teachers_Course.C_ID, Course.C_Name, Course.C_Sarttime, Course.C_Endtime\r\nFROM Teachers_Course\r\n\tLEFT JOIN Teachers ON Teachers_Course.T_ID = Teachers.T_ID\r\n    LEFT JOIN Course ON Teachers_Course.C_ID = Course.C_ID\r\n";
            con.Open();
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(table);
            dgvSchedule.DataSource = table;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserMenu student = new UserMenu();
            this.Hide();
            student.ShowDialog();
            this.Dispose();
        }
    }
}
